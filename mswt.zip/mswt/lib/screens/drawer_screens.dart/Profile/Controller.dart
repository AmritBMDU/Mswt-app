import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Profile_controller extends GetxController{
  RxBool showpassword=false.obs;
  TextEditingController fjkd =TextEditingController();
  TextEditingController password=TextEditingController();
}