

import 'package:flutter/material.dart';
import 'package:mswt/widgets/custom_appbar.dart';

class OfferScreen extends StatelessWidget {
  final List<Product> products = [
    Product("JCB", "Description 1", "assets/img_4.png", 20),
    Product("Tractor", "Description 2", "assets/img_5.png", 30),
    Product("Crane", "Description 3", "assets/img_6.png", 25),
    Product("M12 Tractor", "Description 4", "assets/img_7.png", 15),
      Product("Cultivator", "Description 1", "assets/img_1.png", 20),
    Product("Water pump", "Description 2", "assets/img_4.png", 30),
    Product("Thresher", "Description 3", "assets/img_3.png", 25),
    Product("M12 Tractor", "Description 4", "assets/img_7.png", 15),
    // Add more products as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: customAppBar('Product Offers'),
        automaticallyImplyLeading: false,
        centerTitle: true,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductCard(product: products[index]);
        },
      ),
    );
  }
}

class Product {
  final String name;
  final String description;
  final String imagePath;
  final double discount;

  Product(this.name, this.description, this.imagePath, this.discount);
}

class ProductCard extends StatelessWidget {
  final Product product;

  ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Image.asset(
            product.imagePath,
            height: 90.0,
            //fit: BoxFit.cover,
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(product.description),
                SizedBox(height: 8.0),
                Text(
                  'Discount: ${product.discount}% off',
                  style: TextStyle(color: Colors.green),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
