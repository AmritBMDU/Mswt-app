import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/widgets/custom_appbar.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool isEditing = false;
  // Future PinCodeGenerate(String code)async{
  //   var token = prefs.getString('token');
  //   final response = await http.get(Uri.parse('https://api.postalpincode.in/pincode/$code'),
  //   );
  //   if(response.statusCode == 200){
  //     final data = jsonDecode(response.body);
  //     var  dataa = data[0]['PostOffice'];
  //     country.text = dataa[0]['Country'].toString();
  //     state.text = dataa[0]['State'].toString();
  //     city.text = dataa[0]['Block'].toString();
  //     // print(dataa);
  //     return dataa;
  //   }
  // }

  List<String> data=[];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: customAppBar('My Profile'),
        centerTitle: false,
        actions: [

         if(isEditing==false) IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              setState(() {
                isEditing = !isEditing;
              });
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 70,
                    backgroundImage: NetworkImage('https://placekitten.com/200/200'), // Placeholder image
                  ),
                if(isEditing!=false)  Positioned(
                    bottom: 10,
                   right: 1,
                    child: CircleAvatar(
                    child: Icon(Icons.camera_rounded),
                  ))
                ],
              ),
              SizedBox(height: 20),
              buildProfileField("First Name", "Saurabh", isEditing,Icons.person),
              buildProfileField("Last Name", "Baghel", isEditing,Icons.person),
              buildProfileField("Mobile No", "8979034037", isEditing,Icons.call),
              buildProfileField("Email", "doe@example.com", isEditing,Icons.email),
              buildProfileField("Address", "123 Main St, Cityville", isEditing,Icons.location_city),
              buildProfileField("PinCode", "204215", isEditing,Icons.pin),
              SizedBox(
                height: Get.height*0.025,
              ),
              if(isEditing==true) ElevatedButton(onPressed: (){
                Navigator.pop(context);
              }, 
              style: ElevatedButton.styleFrom(
                backgroundColor: appcolor.redColor
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                Text("Submit",style: TextStyle(color: Colors.white),),
                ],
              )
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildProfileField(String label, String value, bool isEditing,IconData icon,) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: isEditing
          ? Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(10)
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: TextFormField(
                  initialValue: value,
                  decoration: InputDecoration(
                    suffixIcon: Icon(icon),
                    labelText: label,
                    labelStyle: TextStyle(color: appcolor.redColor,fontSize: 16,fontWeight: FontWeight.bold),
                    border: InputBorder.none
                  ),
                ),
            ),
          )
          : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('$label:', style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: appcolor.black),),
                Text(
                    '$value',
                    style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: appcolor.redColor),
                  ),
              ],
            ),
          ),
    );
  }
}
