import 'package:flutter/material.dart';
import 'package:mswt/widgets/custom_appbar.dart';

class NotificationData extends StatefulWidget {
  const NotificationData({super.key});

  @override
  State<NotificationData> createState() => _NotificationState();
}

class _NotificationState extends State<NotificationData> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: customAppBar('Notification'),
        automaticallyImplyLeading: false,
      ),
      body:Column(
        children: [
          Card(
            child:ListTile(
              title: Text('Mild Steel Industrial Machine Spare Parts'),
              subtitle: Text('We are engaged in offering Industrial Machine Spare Parts to our clients. Our range of all products is widely appreciated by our clients.'),

            ),

          ),
          Card(
            child:ListTile(
              title: Text('Mild Steel Industrial Machine Spare Parts'),
              subtitle: Text('We are engaged in offering Industrial Machine Spare Parts to our clients. Our range of all products is widely appreciated by our clients.'),

            ),

          ),
          Card(
            child:ListTile(
              title: Text('Mild Steel Industrial Machine Spare Parts'),
              subtitle: Text('We are engaged in offering Industrial Machine Spare Parts to our clients. Our range of all products is widely appreciated by our clients.'),

            ),

          ),
        ],
      )
    );
  }
}
