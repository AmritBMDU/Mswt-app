

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/drawer_screens.dart/Profile/profile.dart';
import 'package:mswt/screens/drawer_screens.dart/terms&conditions.dart';
import 'package:mswt/widgets/block_button.dart';
import 'package:mswt/widgets/custom_appbar.dart';
import 'package:mswt/widgets/floating_actionbutton.dart';
import 'package:mswt/widgets/gradient_text.dart';
import 'package:share_plus/share_plus.dart';

class referandearn extends StatefulWidget {
  const referandearn({super.key});

  @override
  State<referandearn> createState() => _referandearnState();
}

class _referandearnState extends State<referandearn> {
  String copy= 'NEWMSTRONICS12';
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white

          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'),
          //   fit: BoxFit.fill,
          // ),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Column(
            children: [
              customAppBar('Refer & Earn'),
              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          GradientText(
                            gradient: appcolor.gradient,
                            widget: Text(
                              'Mohit Kumar ',
                              style: TextStyle(fontSize: 16, height: 1),
                            ),
                          ),
                          Text(
                            '+91-987653429',
                            style: TextStyle(
                              fontSize: 12,
                              height: 1,
                            ),
                          ),
                        ],
                      ),
                      TextButton(
                        onPressed: () {
                          Get.to(ProfileScreen());
                        },
                        child: Text(
                          'View Details',
                          style: TextStyle(
                            fontSize: 14,
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  GradientText(
                    gradient: appcolor.gradient,
                    widget: Text(
                      'Refer & Earn',
                      style: TextStyle(fontSize: 16, height: 1),
                    ),
                  ),
                  Text(
                    'Upto Rs. 200 for each referral',
                    style: TextStyle(
                      fontSize: 12,
                      height: 1,
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  DottedBorder(
                    borderType: BorderType.RRect,
                    color: appcolor.newRedColor,
                    radius: Radius.circular(10),
                    child: Container(
                      decoration: BoxDecoration(
                        color: appcolor.greyColor,
                        borderRadius: BorderRadius.circular(
                          10,
                        ),
                      ),
                      padding: EdgeInsets.only(
                        top: 10,
                        left: 10,
                        right: 10,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            copy,
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                          Spacer(),
                          Container(
                            margin: EdgeInsets.only(
                              right: 5,
                            ),
                            width: 1,
                            color: Colors.black,
                            height: Get.height * 0.025,
                          ),
                          InkWell(
                              onTap: (){

                                },
                            child: Container(
                              height: Get.height * 0.022,
                              child: Image.asset('assets/Vector (1).png',color: appcolor.redColor,)

                            ),
                          ),
                          InkWell(
                            onTap: ()async {
                              await Clipboard.setData(ClipboardData(text: copy));
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(

                                  content: Text(copy)));
                            },
                            child: Text(
                              ' Copy',
                              style: TextStyle(
                                fontSize: 16,
                                height: 1,
                                color: Colors.blue[300],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: (){
                          Share.share('$copy',subject: 'MS Tronics');
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 15,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                              border: Border.all(
                                color: appcolor.newRedColor,
                              ),
                              borderRadius: BorderRadius.circular(10)),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: Get.height * 0.022,
                                child: Text(
                                  'Share On',
                                  style: TextStyle(
                                    fontSize: 16,
                                    height: 1.2,
                                  ),
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                child:
                                    Image(image: AssetImage('assets/whatsa.png')),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: Get.height * 0.055,
                        child: blockButton(
                          callback: () {
                            Share.share('$copy',subject: 'MS Tronics');
                          },
                          width: Get.width * 0.3,
                          widget: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                height: Get.height * 0.022,
                                child: Text(
                                  'Share',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    height: 1.2,
                                  ),
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(
                                  left: 5,
                                ),
                                child:
                                Image(
                                    image: AssetImage('assets/share_white.png',)),
                              ),
                            ],
                          ),
                          verticalPadding: 3,
                        ),

                      ),

                    ],
                  ).paddingSymmetric(
                    vertical: 10,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GradientText(
                            gradient: appcolor.gradient,
                            widget: Text(
                              'Contact Us',
                              style: TextStyle(fontSize: 16, height: 1),
                            ),
                          ),
                          Text(
                            'For any queries or help',
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        height: Get.height * 0.055,
                        child: blockButton(
                          callback: () async{

                          },
                          width: Get.width * 0.3,
                          widget: Text(
                            'Call Us',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                height: 1.2),
                          ),
                          verticalPadding: 3,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    children: [
                      Text(
                        'Mail us at ',
                        style: TextStyle(fontSize: 16, height: 1),
                      ),
                      Text(
                        'info@mstronics.com',
                        style: TextStyle(
                            fontSize: 14, height: 1, color: Colors.blue[400]),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  InkWell(
                    onTap: (){
                      Get.to(termsandCondition());
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 15,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: appcolor.newRedColor,
                          ),
                          borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            height: Get.height * 0.022,
                            child: Text(
                              'Legal',
                              style: TextStyle(
                                fontSize: 16,
                                height: 1.2,
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.only(
                              left: 5,
                            ),
                            child:
                                Image(image: AssetImage('assets/iosforward.png')),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ).paddingSymmetric(horizontal: 15),
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }

}
