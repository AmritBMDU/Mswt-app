import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';


class TermsAndConditions extends StatefulWidget {
  const TermsAndConditions({super.key});

  @override
  State<TermsAndConditions> createState() => _TermsAndConditionsState();
}

class _TermsAndConditionsState extends State<TermsAndConditions> {
   bool termsAccepted=false;
    void _showTermsAndConditionsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(30.0),
          child: Container(
            width: Get.width,
            height: Get.height * 0.2,
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Terms and Conditions',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
               Column(
                      children: [
                        Text(
                          '1. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                        ),
                        Text(
                          '2. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                        ),
                        Text(
                          '3. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                        ),
                         Text(
                          '4. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                        ),
                        Text(
                          '5. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                        ),
                        Text(
                          '6. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
                        ),
                        // Add more terms and conditions as needed
                      ],
                    ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text('Close'),
                        ),
                  ElevatedButton(
                          onPressed: () {
                            setState(() {
                               termsAccepted = true; // Set termsAccepted to true on Accept
                            });
                            Navigator.of(context).pop(); // Close the dialog
                          },
                          child: Text('Accept'),
                        ),
                ],
              ),
                ],
              ),
            ),
            // child:
            // AlertDialog(
            //   title:
            //   content: SingleChildScrollView(
            //     child:
            //   ),
            //   actions: [
            //
            //
            //   ],
            // ),
          ),
        );
      },
    );
  }

@override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Checkbox(value: termsAccepted, 
         activeColor: appcolor.redColor,
            onChanged:(value) {
              setState(() {
                termsAccepted=!termsAccepted;
              });
            },),
           // if(termsAccepted)
           TextButton(onPressed:() {
             _showTermsAndConditionsDialog(context);
           }, 
           
           child: Text("Terms & Conditions",style: TextStyle(color: appcolor.redColor),))
            
          ],
        
       
    );

  }


}




