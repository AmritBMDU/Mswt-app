import 'package:flutter/material.dart';


import 'package:mswt/constants/color.dart';


class SearchBox extends StatefulWidget {
  const SearchBox({super.key});

  @override
  State<SearchBox> createState() => _SearchBoxState();
}

class _SearchBoxState extends State<SearchBox> {
TextEditingController search=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: appcolor.black),
        borderRadius: BorderRadius.circular(10)
      ),
      child: Padding(padding:EdgeInsets.symmetric(horizontal: 10),
      
      child: TextFormField(
        decoration: InputDecoration(
          hintText: "Search for Products",
          prefixIcon: Icon(Icons.search),
          border: InputBorder.none
        ),
      ),),
      
    );
  }
}