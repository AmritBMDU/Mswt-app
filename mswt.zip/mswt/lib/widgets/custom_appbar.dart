import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/widgets/gradient_text.dart';

import 'ImagePicker.dart';
imagePickercontroller imageController = Get.put(imagePickercontroller());

Container customAppBar(String title) {
  return Container(
    color: Colors.transparent,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GradientText(
          gradient: appcolor.gradient,
          widget: IconButton(
            icon: Icon(
              Icons.arrow_back_outlined,
              size: 20,color: Colors.black,
            ),
            onPressed: () {
              Get.back();
              imageController.image_path = ''.obs;
            },
          ),
        ),
        // SizedBox(width: Get.width* 0.18,),
        GradientText(
          widget: Text(
            title,
            style: TextStyle(
              height: 2,
              fontSize: 22,color: Colors.black
            ),
          ),
          gradient: appcolor.gradient,
        ),
      ],
    ),
  );
}
