import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/widgets/custom_appbar.dart';

import 'Enquiry.dart';
import 'cartPage.dart';

class Product_detail extends StatefulWidget {
  final name;
  final image;
  const Product_detail({super.key, this.name, this.image});

  @override
  State<Product_detail> createState() => _Product_detailState();
}

class _Product_detailState extends State<Product_detail> {
  var image1;
  var image2;
  var image3;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: customAppBar('${widget.name}') ,
      ),
      body:
      // ListView.builder(
      //   itemCount: data.length,
      //   itemBuilder: (context, index){
      //     return Container(
      //       height: 50,
      //       width: 50,
      //
      //       child: Image.network(data[index],fit: BoxFit.cover,),
      //     );
      //   },
      // ),


      Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
            Padding(
              padding: const EdgeInsets.only(left: 100),
              child: Container(
               height: Get.height * 0.4,

               width: Get.width * 0.6,
               child: Hero(
                   tag: 'Detail',
                   child:image1 == null? Image.asset(widget.image,fit: BoxFit.contain,):Image.network(image1,fit: BoxFit.contain,)),
                         ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20,top: 50),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: (){
                      setState(() {
                        image1 ='https://5.imimg.com/data5/SELLER/Default/2023/1/AV/JK/CV/5565642/industrial-machine-spares-500x500.jpg';
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: appcolor.redColor)
                      ),
                      height: 50,
                         width: 50,
                      child: Image.network('https://5.imimg.com/data5/SELLER/Default/2023/1/AV/JK/CV/5565642/industrial-machine-spares-500x500.jpg',fit: BoxFit.cover,),
                    ),
                  ),
                  SizedBox(height: 10,),
                  InkWell(
                    onTap: (){
                      setState(() {
                        image1 ="https://5.imimg.com/data5/SELLER/Default/2022/7/SX/FX/ZO/3927721/1st-pic-500x500.jpg";
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: appcolor.redColor)
                      ),
                      height: 50,
                      width: 50,
                      child: Image.network("https://5.imimg.com/data5/SELLER/Default/2022/7/SX/FX/ZO/3927721/1st-pic-500x500.jpg",fit: BoxFit.cover,),
                    ),
                  ),
                  SizedBox(height: 10,),
                  InkWell(
                    onTap: (){
                      setState(() {
                        image1 ="https://5.imimg.com/data5/CZ/GD/JP/SELLER-1072712/traub-machine-spares-250x250.jpeg";
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: appcolor.redColor)
                      ),
                      height: 50,
                      width: 50,
                      child: Image.network( "https://5.imimg.com/data5/CZ/GD/JP/SELLER-1072712/traub-machine-spares-250x250.jpeg",fit: BoxFit.cover,),
                    ),
                  ),
                ],
              ),
            )

            ]
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20,left: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${widget.name}',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                // Row(
                //   children: [
                //     Text('4.5',style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20),),
                //     Icon(Icons.star,color: Colors.yellow,),
                //   ],
                // )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 11),
            child: Text('₹ 150 ',style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20),),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text('Description',style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20),),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text('A25 WORM AND WORM WHEEL'
                'A60 WORM AND WORM WHEEL'
                'SPEED GEARS'
                '17 TEETH SPROCKET'
                '45 TEETH SPROCKET'
                '65 TEETH SPROCKET',style: TextStyle(fontSize: 15,),),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
                width: Get.width,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: appcolor.redColor,
                      shape: BeveledRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(5))
                      )
                    ),
                    onPressed: (){
                      Get.to(CartPage(value: 2,));
                    }, child: Text('Add to Cart',style: TextStyle(color: Colors.white),))),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
                width: Get.width,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: appcolor.redColor,
                        shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5))
                        )
                    ),
                    onPressed: (){
                      Get.to(product_send_enquiry());
                    }, child: Text('Enquiry',style: TextStyle(color: Colors.white),))),
          ),

        ],
      ),
    );
  }
}
