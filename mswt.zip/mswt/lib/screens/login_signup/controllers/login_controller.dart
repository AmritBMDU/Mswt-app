import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Login_controller extends GetxController{
RxBool showpassword=false.obs;
TextEditingController mobile=TextEditingController();
TextEditingController password=TextEditingController();

}