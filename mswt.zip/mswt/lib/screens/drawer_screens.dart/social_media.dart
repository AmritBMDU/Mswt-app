import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/widgets/CallingFunction.dart';
import 'package:mswt/widgets/custom_appbar.dart';
import 'package:mswt/widgets/floating_actionbutton.dart';



class socialMedia extends StatefulWidget {
  const socialMedia({super.key});

  @override
  State<socialMedia> createState() => _socialMediaState();
}

class _socialMediaState extends State<socialMedia> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white

          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Column(
            children: [
              customAppBar('Social Media'),
              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              SizedBox(
                height: Get.height * 0.1,
              ),
              Container(
                child: Text(
                  'You can Follow Us On',
                  style: TextStyle(
                    fontSize: 20,
                    // decoration: TextDecoration.underline,
                    // decorationColor: appcolor.newRedColor,
                    height: 1,
                  ),
                ),
              ),
              Center(
                child: Container(
                  height: 1,
                  width: Get.width *0.6,
                  color: appcolor.newRedColor,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Wrap(
                spacing: 10,
                children: [
                  InkWell(
                    onTap: (){
                      call().launchInBrowserView('');
                    },
                    child: Container(
                      child: Image(
                        image: AssetImage(
                          'assets/facebook.png',
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      call().launchInBrowserView('');
                    },
                    child: Container(
                      child: Image(
                        image: AssetImage(
                          'assets/insta.png',
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      call().launchInBrowserView('');
                    },
                    child: Container(
                      child: Image(
                        image: AssetImage(
                          'assets/youtube.png',
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      call().launchInBrowserView('');
                    },
                    child: Container(
                      child: Image.asset('assets/img_9.png',height: 49.88,width: 50,)

                    ),
                  ),
                  InkWell(
                    onTap: (){
                      call().launchInBrowserView('');
                    },
                    child: Container(
                        child: Image.asset('assets/img_08.png',height: 49.88,width: 50,)

                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                child: Text(
                  'Visit Our Website ',
                  style: TextStyle(
                    fontSize: 22,
                    // decoration: TextDecoration.underline,
                    // decorationColor: appcolor.newRedColor,
                    height: 1,
                  ),
                ),
              ),
              Center(
                child: Container(
                  height: 1,
                  width: Get.width *0.6,
                  color: appcolor.newRedColor,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              InkWell(
                onTap: (){
                  call().launchInBrowserView('');
                },
                child: Text(
                  'www.Mstronics.com ',
                  style: TextStyle(
                    fontSize: 15,
                    height: 1,
                  ),
                ),
              ),
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}
