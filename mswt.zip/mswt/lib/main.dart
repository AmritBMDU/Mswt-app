import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/login_signup/views/login.dart';
import 'package:mswt/splash_Screen.dart';
import 'package:shared_preferences/shared_preferences.dart';


void main() {
  runApp( mswt());
}

class mswt extends StatelessWidget {
  const mswt({super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.red,
        hintColor: appcolor.mixColor,
        fontFamily: 'Poppins',
        textTheme: TextTheme()
      ),
      home: splashScreen(),
    );
  }
  // Future whertogo() async {
  //   var sharedpref = await SharedPreferences.getInstance();
  //   var isLoggedIn = sharedpref.getString('token');
  //   print(isLoggedIn);
  //   Timer(Duration(seconds: 2,), () async {
  //     if (isLoggedIn != null) {
  //       if(isLoggedIn !=  ''){
  //         Get.offAll(Home_view());
  //
  //       }else{
  //         Get.offAll(login_view());
  //       }
  //     } else {
  //       Get.offAll(login_view());
  //     }
  //   });
  // }
}