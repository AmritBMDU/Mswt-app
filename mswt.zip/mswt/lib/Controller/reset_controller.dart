import 'package:get/get.dart';

class resetController extends GetxController{

  RxBool showPassword=false.obs;
  RxBool showPassword1=false.obs;
  RxBool showPassword2=false.obs;
}