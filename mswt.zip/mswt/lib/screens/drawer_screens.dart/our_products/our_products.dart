import 'package:flip_card/flip_card.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/widgets/custom_appbar.dart';
import 'package:mswt/widgets/seach_box.dart';

import 'Prouduct_Page.dart';


class OurProducts extends StatefulWidget {
  final int value;
  const OurProducts({super.key, required this.value});

  @override
  State<OurProducts> createState() => _OurProductsState();
}

class _OurProductsState extends State<OurProducts> {
   final List<String> cardProducts=[
 "assets/img_5.png",
    "assets/img_6.png",
     "assets/img_7.png",
    "assets/img_8.png",
     "assets/img_5.png",
    "assets/img_6.png",
     "assets/img_7.png",
    "assets/img_8.png",



  ];
   final List<String> cardProductsName=[
   "JCB Machine",
   "JCB Crane",
   " M12 Tractor",
   "Swaraj Tractor",
     "JCB Machine",
   "JCB Crane",
   " M12 Tractor",
   "Swaraj Tractor"


  ];
  List<String> allproducts=[];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    
    
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: widget.value != 1?Text('WishList'): customAppBar('Our Products'),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      // body: Column(
      //   children: [
      //     SizedBox(
      //       height: 30,
      //     ),
        //     Padding(
        //    padding: const EdgeInsets.all(8.0),
        //    child: Row(
        //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //     children: [
        //       Text("Our Products",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
        //       TextButton(onPressed: (){}, child: Text("View All",style: TextStyle(color: appcolor.redColor),))
        //     ],
        //    ),
        //  ),
      //     OurProductCard(cardProducts: cardProducts, cardProductsName: cardProductsName),
      //   ],
      // ),
     body: Column(
       children: [
       // SizedBox(height: 10,),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: SearchBox(),
        ),
        //  Padding(
        //    padding: const EdgeInsets.all(8.0),
        //    child: Row(
        //     mainAxisAlignment: MainAxisAlignment.center,
        //     children: [
        //       Text("Our Products",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
        //       //TextButton(onPressed: (){}, child: Text("View All",style: TextStyle(color: appcolor.redColor),))
        //     ],
        //    ),
        //  ),
         Expanded(
           child: GridView.builder(
            gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            scrollDirection: Axis.vertical,
            itemCount:cardProducts.length ,
            itemBuilder: (context,index){
              return   InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Product_detail(name: cardProductsName[index],image: cardProducts[index],)));
                },
                child: Card(
                 child: Column(
                   mainAxisAlignment:MainAxisAlignment.spaceAround,
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     Hero(
                       tag: 'Detail',
                       child: Padding(
                         padding: const EdgeInsets.all(7.0),
                         child: Image.asset(
                           cardProducts[index],
                           fit: BoxFit.cover,
                         ),
                       ),
                     ),
                     Center(child: Text(cardProductsName[index],style: TextStyle(color:appcolor.redColor,fontSize: 16,fontWeight: FontWeight.w700 ),))
                   ],
                 ),
                ),
              );
            }
            ),
         ),
       ],
     )
    );
  }
}