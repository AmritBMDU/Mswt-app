import 'dart:async';


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';

import '../../../widgets/block_button.dart';
import '../../../widgets/customtextformfield.dart';
import '../../../widgets/gradient_text.dart';
import '../controllers/register_controller.dart';


class forgotPassword_view extends StatefulWidget {
  const forgotPassword_view({super.key});

  @override
  State<forgotPassword_view> createState() => _forgotPassword_viewState();
}

class _forgotPassword_viewState extends State<forgotPassword_view> {
  registerController controller = Get.put(registerController());

  late StreamSubscription subscription;
  bool isDeviceConnected = false;
  bool isAlertSet = false;
  // getConnectivity() =>
  //     subscription = Connectivity().onConnectivityChanged.listen(
  //           (ConnectivityResult result) async {
  //         isDeviceConnected = await InternetConnectionChecker().hasConnection;
  //         if (!isDeviceConnected && isAlertSet == false) {
  //           showDialogBox();
  //           setState(() => isAlertSet = true);
  //         }
  //       },
  //     );
  // showDialogBox() => showCupertinoDialog<String>(
  //   context: context,
  //   builder: (BuildContext context) => CupertinoAlertDialog(
  //     title: const Text('No Connection'),
  //     content: const Text('Please check your internet connectivity'),
  //     actions: <Widget>[
  //       TextButton(
  //         onPressed: () async {
  //           Navigator.pop(context, 'Cancel');
  //           setState(() => isAlertSet = false);
  //           isDeviceConnected =
  //           await InternetConnectionChecker().hasConnection;
  //           if (!isDeviceConnected && isAlertSet == false) {
  //             showDialogBox();
  //             setState(() => isAlertSet = true);
  //           }
  //         },
  //         child: const Text('OK'),
  //       ),
  //     ],
  //   ),
  // );
  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

@override
  void initState() {
    // TODO: implement initState
    super.initState();
   // getConnectivity();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(

        children: [
         Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
            color: Colors.white
          //   image: DecorationImage(
          //       image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: SingleChildScrollView(

              child: Column(
                children: [
                  SizedBox(
                    height: Get.height * 0.13,
                  ),
                  Container(
                    child: GradientText(
                      gradient: appcolor.gradient,
                      widget: Text(
                        'Forgot Password',
                        style:
                            TextStyle(
                                color: appcolor.redColor,
                                fontSize: 25, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    height: Get.height * 0.055,
                    child: customtextformfield(
                      bottomLineColor: Color(0xffb8b8b8),
                      hinttext: 'Mobile Number',
                      suffixIcon: Icon(Icons.call),
                      newIcon: Icon(Icons.call,color: appcolor.SufixIconColor,),
                      key_type: TextInputType.phone,
                      maxLength: 10,
                    ),
                  ),
                  Container(
                    height: Get.height * 0.055,
                    child: customtextformfield(
                      label: '*',
                      bottomLineColor: Color(0xffb8b8b8),
                      hinttext: 'Enter OTP',
                      suffixIcon: Container(
                        child: Image(
                            image: AssetImage(
                          'assets/otp1.png',
                        )),
                      ),
                      newIcon: Container(
                        child: Image(
                            image: AssetImage(
                          'assets/otp1.png'
                        ),color: appcolor.redColor,),
                      ),
                      key_type: TextInputType.phone,
                      maxLength: 4,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {},
                        child: GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'Send Otp?',
                            style: TextStyle(
                              fontSize: 15,color: appcolor.redColor
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {},
                        child: GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'Resend Otp?',
                            style: TextStyle(
                              fontSize: 15,color: appcolor.redColor
                            ),
                          ),
                        ),
                      ),
                    ],
                  ).paddingSymmetric(horizontal: 10),
                  Container(
                    height: Get.height * 0.055,
                    child: blockButton(
                        width: Get.width * 0.35,
                        widget: Text(
                          'Submit',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              height: 1.2),
                        ),
                        verticalPadding: 3),
                  ),
                  SizedBox(height: Get.height * 0.07),
                  Container(
                    height: Get.height * 0.4,
                    child: Image(
                      image: AssetImage(
                        'assets/image-png 1 (1).png',
                      ),
                      fit: BoxFit.fill,
                    ),
                  ),
                ],
              ).paddingSymmetric(horizontal: 15, vertical: 15),
            ),
          ),
        ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 130,
                width: 140,
                decoration: BoxDecoration(
                  color: appcolor.redColor,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(300),
                    topLeft: Radius.circular(2)
                  )
                ),
              ),
            ],
          )
      ]
      ),
    );
  }
}
