

import 'package:get/get.dart';

class registerController extends GetxController{

  RxString groupValue = '1'.obs;
  bool showPassword=false;
}