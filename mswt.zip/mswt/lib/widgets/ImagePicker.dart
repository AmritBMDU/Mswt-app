import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart' as path_provider;
class imagePickercontroller extends GetxController {
  RxList<XFile> imageList = <XFile>[].obs;
  RxString image_path = ''.obs;
  Future getImagefromgallery() async {
    final dir = await path_provider.getTemporaryDirectory();
    final targetPath = '${dir.absolute.path}/fedback&complaint.jpg';
    final ImagePicker _picker = ImagePicker();
    final image = await _picker.pickImage(
      source: ImageSource.gallery,
    );
    if (image != null) {
      var result = await  FlutterImageCompress.compressAndGetFile(image.path, targetPath,quality: 50);
      image_path.value = result!.path.toString();
    }
  }

  Future getimagefromCamera() async {
    final ImagePicker _picker = ImagePicker();
    final dir = await path_provider.getTemporaryDirectory();
    final targetPath = '${dir.absolute.path}/fedback&complaint.jpg';
    final image = await _picker.pickImage(source: ImageSource.camera);
    if (image != Null) {
     // var result = await  FlutterImageCompress.compressAndGetFile(image!.path, targetPath,quality: 50);
      image_path.value = image!.path.toString();


    }
  }

  Future reset() async {
    image_path.value = '';
  }

  Future removeat(int index) async {
    imageList.removeAt(index);
  }

  Future edit(int index) async {
    XFile image = imageList[index];
    final _picker = ImagePicker();
    try {
      final temp_image = await _picker.pickImage(source: ImageSource.gallery);
      if (temp_image != null) {
        imageList[index] = temp_image;
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }



  Future getmultipleImage() async {
    final dir = await path_provider.getTemporaryDirectory();
    final targetPath = '${dir.absolute.path}/fedback&complaint.jpg';
    final ImagePicker _picker = ImagePicker();
    final selectedImages = await _picker.pickMultiImage(
      imageQuality: 100,
    );

    if (selectedImages.isNotEmpty) {
      for (int i = 0; i < selectedImages.length; i++) {
        imageList.add(selectedImages[i]);
      }
    } else {
      Get.snackbar('Error', 'Please Select Images');
    }
  }
}
