import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/drawer_screens.dart/our_products/our_products.dart';

import '../drawer_screens.dart/our_products/cartPage.dart';
import 'homepage.dart';


late String stringResponse;
late String mapResponse;
late String dataResponse ;

class MainPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() =>_MainPage();
}
class _MainPage extends State<MainPage> {
  int selectedItem = 0;
  var _pageData = [
    HomePage(),
    CartPage(value: 1,),
    OurProducts(value: 0,),
  ];

  @override
  Widget build(BuildContext context) {

    return WillPopScope(
      onWillPop: () async{
        final value =  await showDialog<bool>(
          context: context,
          builder: (context) =>
              AlertDialog(
                title: Text('Are you sure?', style: TextStyle(color: Colors.blueGrey),),
                content: Text('Do you want to exit?', style: TextStyle(color: Colors.blueGrey),),
                actions: <Widget>[
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: appcolor.redColor,
                        shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(2))
                        )
                    ),
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text('No', style: TextStyle(color: Colors.white),),
                  ),
                  SizedBox(height: 30,),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: appcolor.redColor,
                        shape: BeveledRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(2))
                        )
                    ),
                    onPressed: () => Navigator.of(context).pop(true),
                    child: Text('Yes', style: TextStyle(color: Colors.white),),
                  ),
                ],
              ),
        ); if(value !=null){
          return Future.value(value);
        }else{
          return Future.value(false);
        }
      },

      child: Scaffold(
        resizeToAvoidBottomInset: false,
        bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.house),
                label: 'Home', backgroundColor: Color(0xff1f42ba)),
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.cartShopping),label: 'Cart ', backgroundColor: Color(0xff1f42ba)),
            BottomNavigationBarItem(icon: FaIcon(FontAwesomeIcons.heart),label: 'WishList', backgroundColor: Color(0xff1f42ba)),
          ],
          currentIndex: selectedItem,
          onTap: (setvalue) {
            setState(() {
              selectedItem = setvalue;
            });
          },
        ),
        body:
        Container(
          color: Colors.orange,
          child: Center(
            child: _pageData[selectedItem],
          ),
        ),

      ),
    );
  }
}