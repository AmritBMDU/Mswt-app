import 'dart:async';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;



class CartPage extends StatefulWidget {
  final int value;
  const CartPage({super.key, required this.value});
  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  int quantity = 1;
  int quantityy = 1;
  var image = 'assets/image 16.png';
  var Name = 'Double Door';
  var Price ;
  late StreamSubscription subscription;
  bool isDeviceConnected = false;
  bool isAlertSet = false;
  // getConnectivity() =>
  //     subscription = Connectivity().onConnectivityChanged.listen(
  //           (ConnectivityResult result) async {
  //         isDeviceConnected = await InternetConnectionChecker().hasConnection;
  //         if (!isDeviceConnected && isAlertSet == false) {
  //           showDialogBox();
  //           setState(() => isAlertSet = true);
  //         }
  //       },
  //     );
  // showDialogBox() => showCupertinoDialog<String>(
  //   context: context,
  //   builder: (BuildContext context) => CupertinoAlertDialog(
  //     title: const Text('No Connection'),
  //     content: const Text('Please check your internet connectivity'),
  //     actions: <Widget>[
  //       TextButton(
  //         onPressed: () async {
  //           Navigator.pop(context, 'Cancel');
  //           setState(() => isAlertSet = false);
  //           isDeviceConnected =
  //           await InternetConnectionChecker().hasConnection;
  //           if (!isDeviceConnected && isAlertSet == false) {
  //             showDialogBox();
  //             setState(() => isAlertSet = true);
  //           }
  //         },
  //         child: const Text('OK'),
  //       ),
  //     ],
  //   ),
  // );
  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  // Future Updatedata(String url,Object value,context)async{
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var token = prefs.getString('token');
  //   final response = await http.post(Uri.parse('${ApiDomain().baseUrl}$url'),body: jsonEncode(value),
  //       headers: ({
  //         'Content-Type': 'application/json; charset=UTF-8',
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer $token'
  //       }));
  //   if(response.statusCode == 200){
  //     final data = jsonDecode(response.body);
  //     if(data['status']== true){
  //
  //       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>OrderPage()));
  //       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
  //     }else{
  //       alertBoxdialogBox(context, 'Alert', '${data['message']}');
  //     }
  //     return data[0];
  //   }else if(response.statusCode ==404){
  //     Get.offAll(apiDomain().login);
  //   }
  // }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        resizeToAvoidBottomInset: false,
        // bottomNavigationBar:   Container(
        //   decoration: BoxDecoration(
        //     color: Colors.blueAccent,
        //   ),
        //   height: size.height * 0.1,
        //   width: size.width,
        //   child: Column(
        //     children: [
        //       Padding(
        //         padding: const EdgeInsets.all(8.0),
        //         child: Row(
        //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //           children: [
        //             Column(
        //               children: [
        //                 Text('Total: ',style: TextStyle(color:Colors.black,fontWeight: FontWeight.w600),),
        //                 Text('₹$Price',style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600,fontSize: 20),),
        //               ],
        //             ),
        //             ElevatedButton(
        //                 style: ElevatedButton.styleFrom(
        //                     shape: BeveledRectangleBorder(
        //                         borderRadius: BorderRadius.all(Radius.circular(11))
        //                     )
        //                 ),
        //                 child: Text('Check Out',style: TextStyle(color: Colors.black),),
        //                 onPressed: (){
        //                   var value = {
        //                     "amount":Price.toString()
        //                   };
        //                   showDialog(context: context, builder:(context){
        //                     return AlertDialog(
        //                       title: Text('Confirm'),
        //                       content: Text('Do you want to place order?'),
        //                       actions: [
        //                         Row(
        //                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        //                           children: [
        //                             TextButton(onPressed: (){
        //                               Navigator.pop(context);
        //                             }, child: Text('CANCEL',style: TextStyle(color: Colors.black),)),
        //                             ElevatedButton(
        //                                 style:ElevatedButton.styleFrom(
        //                                     backgroundColor: Colors.blueAccent
        //                                 ),
        //                                 onPressed: (){}, child: Text('Yex',style: TextStyle(color: Colors.white),))
        //                           ],
        //                         )
        //                       ],
        //                     );
        //                   });
        //                   //Updatedata('order', value, context);
        //                 })
        //           ],
        //         ),
        //       )
        //     ],
        //   ),
        // ),
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Color(0xffEEEEEE),
          title: Text('Cart', style: TextStyle(fontSize: 20,color: Colors.black),),
          automaticallyImplyLeading: false,
          leading: widget.value != 1? IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon:Icon(Icons.arrow_back,)):null,
        ),
        body:
        Column(
          children: [
            Card(
              elevation: 4,
              color: Color(0xffEEEEEE),
              child: ListTile(
                leading: Container(
                    height: 50,
                    width: 50,
                    child: Image.network('https://5.imimg.com/data5/SELLER/Default/2023/8/330962099/WH/IM/UA/126797271/industrial-machine-spare-parts-500x500.jpg',fit: BoxFit.cover,)),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Text('Name: ',style: TextStyle(
                          fontSize: 14,
                          color: Colors.blueAccent,
                          height: 0.9,
                        ),),
                        Text('Mild Steel',style: TextStyle(
                          fontSize: 14,
                          height: 0.9,
                        ),),
                      ],
                    ),
                    IconButton(onPressed: (){
                      // var value = {
                      //   "cart_id":data.id,
                      // };
                      // Api().Update('removeCart', value, context);
                      // CartListData.Items.remove(data);
                      setState(() {});
                    }, icon: Icon(Icons.delete,color: Colors.red,))
                  ],
                ),

                subtitle:Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Price: ',style: TextStyle(
                          fontSize: 14,
                          color: Colors.blueAccent,
                          height: 0.9,
                        ),),
                        Text('₹ 150',style: TextStyle(
                          fontSize: 14,
                          height: 0.9,
                        ),),
                      ],
                    ),
                    SizedBox(height: 5,),
                    Container(
                      height: 40,
                      width: 80,
                      decoration: BoxDecoration(
                          color: Colors.white, // Set your desired background color
                          borderRadius: BorderRadius.circular(5.0)),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  if(quantity != '1'){
                                    if(quantity <=1){

                                    }else{
                                      quantity  =  (int.parse(quantity.toString())-1);
                                    }

                                  }
                                });
                              },
                              child: Padding(
                                  padding: const EdgeInsets.only(right: 1.0),
                                  child:Icon(Icons.remove,color: Colors.black,)
                              ),
                            ),
                            SizedBox(width: 2,),
                            Text(
                              '${int.parse(quantity.toString()) }',
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(width: 2,),
                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  quantity  = (int.parse(quantity.toString())+1);
                                  // var value = {
                                  //   "id":data.id,
                                  //   "quantity":data.quantity
                                  // };
                                  // Update(value);
                                }
                                );
                              },
                              child: Padding(
                                  padding: const EdgeInsets.only(left: 3.0),
                                  child: Icon(Icons.add,color: Colors.black,)
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            Card(
              elevation: 4,
              color: Color(0xffEEEEEE),
              child: ListTile(
                leading: Container(
                    height: 50,
                    width: 50,
                    child: Image.network('https://5.imimg.com/data5/SELLER/Default/2023/8/330962099/WH/IM/UA/126797271/industrial-machine-spare-parts-500x500.jpg',fit: BoxFit.cover,)),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Text('Name: ',style: TextStyle(
                          fontSize: 14,
                          color: Colors.blueAccent,
                          height: 0.9,
                        ),),
                        Text('Mild Steel',style: TextStyle(
                          fontSize: 14,
                          height: 0.9,
                        ),),
                      ],
                    ),
                    IconButton(onPressed: (){
                      // var value = {
                      //   "cart_id":data.id,
                      // };
                      // Api().Update('removeCart', value, context);
                      // CartListData.Items.remove(data);
                      setState(() {});
                    }, icon: Icon(Icons.delete,color: Colors.red,))
                  ],
                ),

                subtitle:Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Price: ',style: TextStyle(
                          fontSize: 14,
                          color: Colors.blueAccent,
                          height: 0.9,
                        ),),
                        Text('₹ 150',style: TextStyle(
                          fontSize: 14,
                          height: 0.9,
                        ),),
                      ],
                    ),
                    SizedBox(height: 5,),
                    Container(
                      height: 40,
                      width: 80,
                      decoration: BoxDecoration(
                          color: Colors.white, // Set your desired background color
                          borderRadius: BorderRadius.circular(5.0)),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  if(quantityy!= '1'){
                                        if(quantityy <=1){

                                        }else{
                                          quantityy =  (int.parse(quantityy.toString())-1);
                                        }

                                  }
                                });
                              },
                              child: Padding(
                                  padding: const EdgeInsets.only(right: 1.0),
                                  child:Icon(Icons.remove,color: Colors.black,)
                              ),
                            ),
                            SizedBox(width: 2,),
                            Text(
                              '${int.parse(quantityy.toString()) }',
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(width: 2,),
                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  quantityy  = (int.parse(quantityy.toString())+1);
                                  // var value = {
                                  //   "id":data.id,
                                  //   "quantity":data.quantity
                                  // };
                                  // Update(value);
                                }
                                );
                              },
                              child: Padding(
                                  padding: const EdgeInsets.only(left: 3.0),
                                  child: Icon(Icons.add,color: Colors.black,)
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        )
    );
  }


}
