import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/home/homepage.dart';
import 'package:mswt/screens/login_signup/controllers/register_controller.dart';
import 'package:mswt/screens/login_signup/views/login.dart';
import 'package:mswt/widgets/block_button.dart';
import 'package:mswt/widgets/customtextformfield.dart';
import 'package:mswt/widgets/gradient_text.dart';
import 'package:mswt/widgets/terms_conditions.dart';

class register_view extends StatefulWidget {
  const  register_view({super.key});

  @override
  State<register_view> createState() => _register_viewState();
}

class _register_viewState extends State<register_view> {
  bool isSelected = false;
  bool isshow=false;
  registerController controller = Get.put(registerController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isshow=true;
  }
  @override
  Widget build(BuildContext context) {
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return Colors.red;
    }
    return SafeArea(
      child: Stack(
        children: [
         Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
            color: Colors.white
            // image: DecorationImage(
            //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: Column(
              children: [
                SizedBox(
                     height: Get.height * 0.08,
                    ),
                Container(
                  child: GradientText(
                    gradient: appcolor.gradient,
                    widget: Text(
                      'Sign Up',
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold,color: appcolor.redColor),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    label: '*',
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Name',
                    suffixIcon: Icon(Icons.person),
                    newIcon: Icon(Icons.person,color: appcolor.SufixIconColor),
                    // border: InputBorder.none,
                   key_type: TextInputType.visiblePassword,
                  ),
                ),
                Container(
                  height: Get.height * 0.055,
                  child:


                  customtextformfield(
                    label: '*',
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Mobile Number',
                    suffixIcon: Icon(Icons.call,),
                    newIcon: Icon(Icons.call,color: appcolor.SufixIconColor),
                    key_type: TextInputType.phone,
                    maxLength: 10,
                  ),
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    label: '*',
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Create Password',
                    suffixIcon:IconButton( 
                      icon: Icon(isshow
                          ? Icons.visibility 
                          : Icons.visibility_off), 
                      onPressed: () { 
                        setState( 
                          () { 
                            isshow = !isshow; 
                          }, 
                        ); 
                      }, 
                    ), 
                    key_type: TextInputType.visiblePassword,
                    showPassword: isshow
                  ),
                ),
              
                SizedBox(height: 8,),

               
               TermsAndConditions(),
          
         
              SizedBox(
              height: 10,
            ),
                Container(
                  height: Get.height * 0.055,
                  child: blockButton(
                    callback: () {
Get.to(HomePage());
                    },
                    width: Get.width * 0.35,
                    widget: Text(
                      'Sign Up',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          height: 1.2),
                    ),
                    verticalPadding: 3,
                  ),
                ),
                 SizedBox(
                    height: Get.height * 0.01,
                    ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      child:  GradientText(
                        widget: Text(
                            'Have MS Tronics account? ',
                            style: TextStyle(
                              fontSize: 15,color: Colors.black,fontWeight: FontWeight.bold
                            ),
                          ), gradient: appcolor.gradient,
                      ),

                    ),
                    InkWell(
                      onTap: () {
                        Get.offAll(login_view());
                      },
                      child: Stack(
                        children: [
                          Container(
                            child: GradientText(
                              widget: Text(
                                'Login',
                                style: TextStyle(
                                  height: 1,
                                  fontSize: 15,color: appcolor.redColor,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              gradient: appcolor.gradient,
                            ),
                          ),
                          Column(
                            children: [
                              SizedBox(
                                height: 18,
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                    height: Get.height * 0.03,
                    ),
                Container(
                   height: Get.height * 0.40,
                  child: Image(
                    image: AssetImage(
                      'assets/login1.png',
                    ),
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ).paddingSymmetric(horizontal: 15, vertical: 15),
          ),
        ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 130,
                width: 140,
                decoration: BoxDecoration(
                    color: appcolor.redColor,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(300),
                        topLeft: Radius.circular(2)
                    )
                ),
              ),
            ],
          )
      ]
      ),
    );
  }
}

Widget customwidget(String type) {
  //electric
  if (type == '1') {
    return Container(
      height: Get.height * 0.055,
      child: customtextformfield(hinttext: 'Dealer/Partner CIN',bottomLineColor: Color(0xffb8b8b8),
        key_type: TextInputType.visiblePassword,),
    );
  } else if (type == '2') {
    return Container(
      child: Column(
        children: [
          Container(
              height: Get.height * 0.055,
              child: customtextformfield(hinttext: 'Business Name',bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.visiblePassword,
              )),

          Container(
              height: Get.height * 0.055,
              child: customtextformfield(hinttext: 'Partner CIN',bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.visiblePassword,
              )),
        ],
      ),
    );
  } else {
    return Container(
      height: Get.height * 0.055,
      child: customtextformfield(hinttext: 'Business Name',bottomLineColor: Color(0xffb8b8b8),
        key_type: TextInputType.visiblePassword,),
    );
  }
}
