
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import 'dart:io';

import 'package:mswt/constants/color.dart';

import '../../../widgets/block_button.dart';

class product_send_enquiry extends StatelessWidget {
  product_send_enquiry({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
           // color: appcolor.redColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        title: Text(
          'Send Enquiry',
          style: TextStyle(
            color: appcolor.redColor,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: CustomScrollView(
        slivers: [
          SliverList.list(
            children: [

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Text(
                      'Title',
                      style: TextStyle(
                          color: appcolor.redColor, fontSize: 18),
                    ),
                  ),
                  Container(
                    height: Get.height * 0.09,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        8,
                      ),
                      border: Border.all(color: appcolor.redColor),
                      color: Colors.white,
                    ),
                    child: Center(
                      child: TextFormField(
                        decoration: InputDecoration(
                          enabledBorder: InputBorder.none,
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 10,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * 0.04,
                  ),
                  Container(
                    child: Text(
                      'Description',
                      style: TextStyle(
                          color: appcolor.redColor, fontSize: 18),
                    ),
                  ),
                  Container(
                    height: Get.height * 0.2,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        8,
                      ),
                      border: Border.all(color: appcolor.redColor),
                      color: Colors.white,
                    ),
                    child: TextFormField(
                      maxLines: 4,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 10,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * 0.05,
                  ),
                ],
              ).paddingSymmetric(
                horizontal: 20,
                vertical: 5,
              ),
      Padding(
          padding: const EdgeInsets.all(15.0),
          child: blockButton(
            widget: Text(
              'Send Enquiry',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w300,
                  fontSize: 16),
            ),
            callback: () {},
           // color: appcolor.redColor,
          ),
        ),
            ],
          )
        ],
      ),

    );
  }
}
