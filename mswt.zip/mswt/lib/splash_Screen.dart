import 'dart:async';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/home/MainScreen.dart';
import 'package:mswt/screens/home/homepage.dart';
import 'package:mswt/screens/login_signup/views/login.dart';
import 'package:shared_preferences/shared_preferences.dart';



class splashScreen extends StatefulWidget {
  splashScreen({super.key});
  @override
  State<splashScreen> createState() => _splashScreenState();
}

class _splashScreenState extends State<splashScreen> {

  @override
  void initState() {
    // TODO: implement initState
    whertogo();
    // Timer(Duration(seconds: 2),(){
    //   Get.off(login_view());
    // });
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child:Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: Colors.white,
        child:Column(
          children: [
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                            blurRadius: 2,
                            spreadRadius: 0
                        )
                      ],
                      color: appcolor.redColor,
                      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(600))
                  ),
                  height: Get.height * 0.5,
                  width: Get.width,
                ),

                Padding(
                  padding: const EdgeInsets.only(top:150),
                  child: Center(
                    child:Image.asset('assets/appLogo.png',fit: BoxFit.cover,width: 100,color: Colors.white,),
                  ),
                ),
              ],
            ),
            SizedBox(height: 50,),
             Center(
               child: SizedBox(
                   width: 250.0,
                   child: DefaultTextStyle(
                   style: const TextStyle(
                   fontSize: 25.0,color: Colors.black,
                   fontWeight: FontWeight.bold
                   ),
                   child: Center(
                     child: AnimatedTextKit(
                         animatedTexts: [
                TyperAnimatedText('Welcome in MSWT',),
                           ],
               onTap: () {},
                        ),
                   ),
                     ),
                   ),
             )
          ],
        ),

      ),

    );
  }
  Future whertogo() async {
    var sharedpref = await SharedPreferences.getInstance();
    var isLoggedIn = sharedpref.getString('token');
    print(isLoggedIn);
    Timer(Duration(seconds: 2,), () async {
      if (isLoggedIn != null) {
        if(isLoggedIn !=  ''){
          Get.offAll(MainPage());

        }else{
          Get.offAll(login_view());
        }
      } else {
        Get.offAll(login_view());
      }
    });
  }

}
