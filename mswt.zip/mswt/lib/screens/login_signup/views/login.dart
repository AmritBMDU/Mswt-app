import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/home/homepage.dart';
import 'package:mswt/screens/login_signup/controllers/login_controller.dart';
import 'package:mswt/screens/login_signup/views/register.dart';
import 'package:mswt/widgets/CallingFunction.dart';
import 'package:mswt/widgets/alertBox.dart';
import 'package:mswt/widgets/block_button.dart';
import 'package:mswt/widgets/customtextformfield.dart';
import 'package:mswt/widgets/gradient_text.dart';
import 'package:shared_preferences/shared_preferences.dart';


class login_view extends StatefulWidget {
  const login_view({super.key});

  @override
  State<login_view> createState() => _login_viewState();
}

class _login_viewState extends State<login_view> {
    Login_controller  controller = Get.put( Login_controller());
  var value = null;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
           Container(
            height: Get.height,
            width: Get.width,
            decoration: BoxDecoration(
              color: Colors.white,
            //   image: DecorationImage(
            //       image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
            ),
            child: Scaffold(
              backgroundColor: Colors.transparent,
              resizeToAvoidBottomInset: false,
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: Get.height *0.1,
                    ),
                    Container(
                      child: GradientText(
                        gradient: appcolor.gradient,
                        widget: Text(
                          'Login',
                          style:
                              TextStyle(fontSize: 30, fontWeight: FontWeight.bold,color: appcolor.redColor),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      height: Get.height * 0.055,
                      child: customtextformfield(
                       controller: controller.mobile,
                        bottomLineColor: Color(0xffb8b8b8),
                        hinttext: 'Mobile Number',
                        suffixIcon: Icon(Icons.call),
                        newIcon: Icon(Icons.call,color: appcolor.SufixIconColor,),
                        key_type: TextInputType.phone,
                        maxLength: 10,

                      
                        
                      ),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      child: customtextformfield(
                         controller: controller.password,
                          hinttext: 'Password',
                          bottomLineColor: Color(0xffb8b8b8),
                          suffixIcon: Icon(Icons.lock),
                          newIcon: controller.showpassword.value? Icon(
                            Icons.lock_open,color: appcolor.SufixIconColor,
                          ):Icon(
                            Icons.lock,color: appcolor.SufixIconColor,
                          ),
                          showPassword: controller.showpassword.value,
                          key_type: TextInputType.visiblePassword,
                          callback: () {
                            controller.showpassword.value =
                                !controller.showpassword.value;
                        
                            setState(() {
                             
                            });
                          }),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      child: blockButton(
                        callback: () async{
                          var pref = await SharedPreferences.getInstance();
                         controller.mobile.text.isEmpty|| controller.password.text.isEmpty?showDialog(context: context, builder: (context){
                           return AlertDialog.adaptive(
                           //  title: Text("Alert"),
                           title: SizedBox(
                            height: 10,
                           ),
                             actions: [Column(
                               children: [
                                 Center(
                                   child: Container(
                                    height: Get.height*0.1,
                                                              //   width: Get.width*0.1,
                                    child: Image.asset("assets/login_warning.png")),
                                 ),
                                 
                                 Padding(
                                   padding: const EdgeInsets.all(8.0),
                                   child: Text("All fileds are mendatory",style: TextStyle(fontSize: 18,color:appcolor.redColor ),),
                                 ),
                                 ElevatedButton(onPressed: (){
                                 Navigator.pop(context);
                                 }, child: Text("Ok"))
                               ],
                             )],
                             
                           );
                         })
                             :
                             pref.setString('token', controller.mobile.text.toString());
                         Get.to(HomePage());
                        },
                        width: Get.width * 0.3,
                        widget: Text(
                          'Login',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              height: 1.2),
                        ),
                        verticalPadding: 3,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        //Get.to(forgotPassword_view());
                      },
                      child: Container(
                        child: GradientText(
                          widget: Text(
                            'Forget Password?',
                            style: TextStyle(
                              fontSize: 15,color: appcolor.redColor
                            ),
                          ),
                          gradient: appcolor.gradient,
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          child:  GradientText(
                            gradient: appcolor.gradient,
                            widget: Text(
                                'Don\'t have any account? ',
                                style: TextStyle(
                                  fontSize: 15,
                                ),
                              ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            Get.to(register_view());
                          },
                          child: Stack(
                            children: [
                              Container(
                                child: GradientText(
                                  widget: Text(
                                    'SignUp',
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,color: appcolor.redColor
                                    ),
                                  ),
                                  gradient: appcolor.gradient,
                                ),
                              ),
                              Column(
                                children: [
                                  SizedBox(
                                    height: 20,
                                  ),
                        
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: Get.height * 0.038,
                    ),
                    Container(
                      child: Image(
                        image: AssetImage(
                          'assets/login1.png',
                        ),
                      ),
                    ),
                    //SizedBox(height: 50,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Helpline No:- ',style: TextStyle(color: appcolor.redColor),),
                        InkWell(
                            onTap: (){
                              call().makePhoneCall('9823564784');
                            },
                            child: Text('+91 9823564784'))
                      ],
                    ),
                    InkWell(
                        onTap: (){
                          alertBoxdialogBox(context, 'Terms & Condition', 'When your business operates online, you’re connected to a world wide web of potential customers, connections, and networks. But you’re also exposing your business to several risks and threats — sometimes at the hands of your own consumers.'

                          'So how do you keep your business safe? It’s easy, you just need a terms and conditions agreement.'

                          'A website or mobile app’s terms and conditions policy outlines rules and guidelines users are expected to follow and covers topics like dispute resolutions, payment terms, intellectual property rights, and more.'

                          'As long as your rules fall within applicable laws and you can prove users knowingly read and agreed to the document, it can even hold up in a court of law, making it an essential legal policy.'

                          'Read on to learn more about terms and conditions agreements, why you should have one, and how to implement one using our sample terms and conditions template.');
                        },
                        child: Text('Terms & Condition ',style: TextStyle(color: appcolor.redColor),)),
                        
                        
                  ],
                ).paddingSymmetric(horizontal: 15, vertical: 15),
              ),
            ),
          ),

        ]
        ),
      ),
    );
  }
}
