import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/drawer_screens.dart/about_us.dart';
import 'package:mswt/widgets/custom_appbar.dart';
import 'package:mswt/widgets/floating_actionbutton.dart';



class termsandCondition extends StatefulWidget {
  const termsandCondition({super.key});

  @override
  State<termsandCondition> createState() => _termsandConditionState();
}

class _termsandConditionState extends State<termsandCondition> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
    
        child: Scaffold(
          appBar: AppBar(
            title: customAppBar('Terms & Conditions'),
            automaticallyImplyLeading: false,
            centerTitle: true,
            elevation: 0,
          ),
         // backgroundColor: Colors.transparent,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              
              // Container(
              //   height: 1,
              //   width: Get.width,
              //   color: appcolor.borderColor,
              // ),
              SizedBox(height: 10,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '1. PayTm : Any Amount equal or above Rs. 1',
                    style: TextStyle(fontSize: 14),
                  ),
                  Text(
                    '2. Bank Transfer : Any Amount equal or above\n   Rs.300 ',
                    style: TextStyle(fontSize: 14),
                  ),
                  Text(
                    'Disclaimer',
                    style: TextStyle(
                      color: appcolor.newRedColor,
                      fontSize: 18,
                    ),
                  ),
                  Text(
                    '1. Please note as, per CBDTwhen an unknown\n   printer took a galley of type and scrambled \n   it to make a type specimen book. It has \n   survived not only five centuries, ',
                    style: TextStyle(fontSize: 14),
                  ),
                  Text(
                    '2. Please note as, per CBDTwhen an unknown\n   printer took a galley of type and scrambled \n   it to make a type specimen book. It has \n   survived not only five centuries, ',
                    style: TextStyle(fontSize: 14),
                  ),
                  Text(
                    'End User Liscence Agreement',
                    style: TextStyle(
                      color: appcolor.newRedColor,
                      fontSize: 18
                    ),
                  ),
                  Text(
                    'To Know more About us please click on the button',
                    style: TextStyle(
                      fontSize: 14,
                      height: 1,
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Get.to(aboutUs());
                    },
                    child: Text(
                      'Click Here',
                      style: TextStyle(
                        fontSize: 16,
                        height: 1,
                      ),
                    ),
                  )
                ],
              ).paddingSymmetric(
                horizontal: 10,
              ),
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      
    );
  }
}
