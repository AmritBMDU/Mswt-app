// import 'package:flutter/material.dart';

import 'dart:ui';

import 'package:flutter/material.dart';

class appcolor {

  static final Color redColor = Color.fromARGB(255, 28, 108, 221);
  static final Color purpleColor = Colors.black;
  static final Color mixColor = Color.fromARGB(255, 28, 86, 221);
  static final Color black = Colors.black;
  static final Color greyColor = Color(0xffEEEEEE);
  static final Color borderColor = Colors.black;
  static final Color SufixIconColor = Color.fromARGB(255, 28, 80, 221);
  static final Color newRedColor = Color.fromARGB(255, 28, 92, 221);
  static final LinearGradient gradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,

    // stops: [0.9,0.1],
    colors: [
      Color.fromARGB(255, 74, 43, 195),
      Color.fromARGB(255, 37, 78, 181),
    ],
  );
  static final LinearGradient voidGradient = LinearGradient(
    // stops: [0.9,0.1],
    colors: [
      Colors.black,
    ],
  );
}
