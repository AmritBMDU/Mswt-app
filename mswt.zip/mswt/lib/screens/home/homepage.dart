

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/widgets/drawer.dart';
import 'package:mswt/widgets/floating_actionbutton.dart';
import 'package:mswt/widgets/seach_box.dart';

import '../../widgets/CallingFunction.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
   final List<String> productImages = [
    "assets/img_1.png",
    "assets/img_2.png",
     "assets/img_3.png",
    "assets/img_4.png",
    // Add more image URLs for your products
  ];
  final List<String> cardProducts=[
 "assets/img_5.png",
    "assets/img_6.png",
     "assets/img_7.png",
    "assets/img_8.png",


  ];
   final List<String> cardProductsName=[
   "JCB Machine",
   "JCB Crane",
   " M12 Tractor",
   "Swaraj Tractor"


  ];
  int _currentPage = 0;
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: Get.height*0.1,
       // automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: appcolor.redColor),
        centerTitle: true,
       // leading: Icon(Icons.menu,color: appcolor.redColor,),
        title:  Container(
                height: Get.height*0.3,
                width: Get.width*0.3,
              //  color: Colors.black,
                child: Image.asset("assets/white_logo.png")),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Icon(Icons.notifications_active,color: appcolor.redColor,),
          ),
          
                      Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: InkWell(
                            onTap: (){
                              call().makePhoneCall('9823564784');
                            },
                            child: Icon(Icons.call,color: appcolor.redColor,)),
                      ),
           
        ],
      ),
      drawer: Drawer(
        child: MyDrawer(),
      ),
      floatingActionButton: floatingActionButon(),
      body:SingleChildScrollView(
        child: Column(
          children: [
            // Carousel Slider with Dynamic Dot Indicators
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SearchBox(),
          ),
            CarouselSlider.builder(
              itemCount: cardProducts.length,
              options: CarouselOptions(
                height: 240.0,
                autoPlay: true,
                enlargeCenterPage: true,
                aspectRatio: 16 / 9,
                autoPlayCurve: Curves.fastOutSlowIn,
                enableInfiniteScroll: true,
                autoPlayAnimationDuration: Duration(milliseconds: 800),
                viewportFraction: 0.8,
                onPageChanged: (index, reason) {
                  setState(() {
                    _currentPage = index;
                  });
                },
              ),
              itemBuilder: (BuildContext context, int index, int realIndex) {
                return Container(
                  width: Get.width*1.4,
                  margin: EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Card(
                      child: Image.asset(
                       cardProducts[index],
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              },
            ),
                      
            // Dynamic Dot Indicators
            DotsIndicator(
              dotsCount: productImages.length,
              position: _currentPage,
              decorator: DotsDecorator(
                color: Colors.grey, // Inactive dot color
                activeColor: Colors.blue, // Active dot color
                spacing: EdgeInsets.all(5.0), // Space between dots
              ),
            ),
         Padding(
           padding: const EdgeInsets.all(8.0),
           child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Our Products",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
              TextButton(onPressed: (){
                
              }, child: Text("View All",style: TextStyle(color: appcolor.redColor),))
            ],
           ),
         ),
                   OurProductCard(cardProducts: cardProducts, cardProductsName: cardProductsName),
           Padding(
           padding: const EdgeInsets.all(8.0),
           child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("New Products",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
              TextButton(onPressed: (){}, child: Text("View All",style: TextStyle(color: appcolor.redColor),)),

            ],
           ),
           
         ),
         OurProductCard(cardProducts: productImages, cardProductsName: cardProductsName)          
          ],
        ),
      ),

          // Featured Products List
          
           
        

      
    );
  }
}

class OurProductCard extends StatelessWidget {
  const OurProductCard({
    super.key,
    required this.cardProducts,
    required this.cardProductsName,
  });

  final List<String> cardProducts;
  final List<String> cardProductsName;

  @override
  Widget build(BuildContext context) {
    return Container(
                height: 260.0,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: cardProducts.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
     margin: EdgeInsets.all(8.0),
     width: 200.0, // Set the desired width
     child: FlipCard(
       direction: FlipDirection.HORIZONTAL,
       front: Card(
         child: Column(
           mainAxisAlignment:MainAxisAlignment.spaceAround,
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Padding(
               padding: const EdgeInsets.all(8.0),
               child: Image.asset(
                 cardProducts[index],
                 fit: BoxFit.cover,
               ),
             ),
             Center(child: Text(cardProductsName[index],style: TextStyle(color:appcolor.redColor,fontSize: 16,fontWeight: FontWeight.w700 ),))
           ],
         ),
       ),
       back: Card(
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Text(
                             cardProductsName[index],
               style: TextStyle(
                 fontSize: 16.0,
                 fontWeight: FontWeight.bold,
               ),
             ),
               SizedBox(height: 20,),
                   Padding(
                     padding: const EdgeInsets.all(8.0),
                     child: Text('''Modern tractors mein advanced technology ka Bhrosa '''
                     ,style: TextStyle(fontSize: 14,fontWeight: FontWeight.w600),),
                   ),
                     Padding(
                     padding: const EdgeInsets.all(8.0),
                     child: Text('''Modern tractors mein advanced technology ka '''
                     ,style: TextStyle(fontSize: 14,fontWeight: FontWeight.w600),),
                   ),
                      Padding(
                     padding: const EdgeInsets.all(8.0),
                     child: Text('''Modern tractors mein advanced technology ka '''
                     ,style: TextStyle(fontSize: 14,fontWeight: FontWeight.w600),),
                   ),
                   
           ],
         ),
       ),
     ),
                    );
                  },
                ),
              );
  }
}