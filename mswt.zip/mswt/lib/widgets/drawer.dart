import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mswt/constants/color.dart';
import 'package:mswt/screens/drawer_screens.dart/about_us.dart';
import 'package:mswt/screens/drawer_screens.dart/app_share.dart';
import 'package:mswt/screens/drawer_screens.dart/offers.dart';
import 'package:mswt/screens/drawer_screens.dart/order_history.dart';
import 'package:mswt/screens/drawer_screens.dart/our_products/machine_parts.dart';
import 'package:mswt/screens/drawer_screens.dart/our_products/our_products.dart';
import 'package:mswt/screens/drawer_screens.dart/Profile/profile.dart';
import 'package:mswt/screens/drawer_screens.dart/social_media.dart';
import 'package:mswt/widgets/terms_conditions.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../screens/drawer_screens.dart/Feedback & Complaint.dart';
import '../screens/drawer_screens.dart/Reset_Password.dart';
import '../screens/drawer_screens.dart/our_products/cartPage.dart';
import '../screens/drawer_screens.dart/terms&conditions.dart';
import '../screens/login_signup/views/login.dart';

class MyDrawer extends StatefulWidget {
  const MyDrawer({super.key});

  @override
  State<MyDrawer> createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 35,right: 8,left: 8,bottom: 8),
            child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfileScreen()));
              },
              child: Container(
                height: Get.height*0.12,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(10),
                  color: appcolor.newRedColor
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(width: 5,),
                    CircleAvatar(
                      radius: 35,
                      backgroundImage: AssetImage("assets/logo.png"),
                    ),
                    SizedBox(width: 10,),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Saurabh Baghel",style: TextStyle(color: Colors.white,fontSize: 17,fontWeight: FontWeight.bold),),
                        Text("8979034037",style: TextStyle(color: Colors.white,fontSize: 17,fontWeight: FontWeight.bold),),
                        // Text("Email-abc12@gmail.com",style: TextStyle(color: Colors.white,fontSize: 17,fontWeight: FontWeight.bold),)
                      ],
                    )
                  ],
                ),
              
                    
              ),
            ),
          ),
          // Padding(
          //   padding: const EdgeInsets.symmetric(horizontal: 10),
          //   child: ListTile(
          //    // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
          //     leading: Icon(Icons.person,color: appcolor.redColor,),
          //     title: Text("Profile"),
          //     onTap: (){
          //       Get.to(ProfileScreen());
          //     },
             
          //   ),
          // ),
           Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
           //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.emoji_objects,color: appcolor.redColor,),
              title: Text("Our Products"),
              onTap:(){
                Get.to(OurProducts(value: 1,));
              },
            ),
          ),
            Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
           //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.emoji_objects,color: appcolor.redColor,),
              title: Text("Our Machine Parts"),
              onTap:(){
                Get.to(MachineParts());
              },
            ),
          ),
          Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
              //shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.discount,color: appcolor.redColor,),
              title: Text("Offers"),
              onTap: (){
                Get.to(OfferScreen());
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal:5),
            child: ListTile(
              onTap: (){
                Get.to(CartPage(value: 2,));
              },
           //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.shopping_basket,color: appcolor.redColor,),
              title: Text("Cart"),
            ),
          ),
            Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
           //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.favorite,color: appcolor.redColor,),
              title: Text("WishList"),
              onTap:(){
                Get.to(OurProducts(value: 1,));
              },
            ),
          ),
            Padding(
             padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
          //    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.history,color: appcolor.redColor,),
              title: Text("Order History"),
             onTap: (){
              Get.to(OrderHistory());
             },
            ),
          ),
           Padding(
             padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
           //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.info_rounded,color: appcolor.redColor,),
              title: Text("About us"),
             onTap: (){
              Get.to(aboutUs());
             },
            ),
          ),
           Padding(
             padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
             // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.verified,color: appcolor.redColor,),
              title: Text("Social Media"),
              onTap: (){
                Get.to(socialMedia());
              },
             
            ),
          ),
           Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
            //  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.share,color: appcolor.redColor,),
              title: Text("App share"),
              onTap: (){
                Get.to(referandearn());
              },
            ),
          ),
           Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
              onTap: (){
                Get.to(Feedback_Complaints());
              },
            //  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.feedback,color: appcolor.redColor,),
              title: Text("Feedback & Complain"),
            ),
          ),
           Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
              onTap: (){
                Get.to(reset_password());
              },
            //  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.restart_alt_sharp,color: appcolor.redColor,),
              title: Text("Reset Password"),
            ),
          ),
           Padding(
             padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
              onTap: (){
                Get.to(termsandCondition());
              },
            //  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.policy,color: appcolor.redColor,),
              title: Text("Terms and conditions"),
            ),
          ),
          Divider(
            thickness: 2,
          ),
             Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: ListTile(
              onTap:   () async{
    SharedPreferences preferences = await SharedPreferences.getInstance();
        showDialog<bool>(
          context: context,
              builder: (context) =>
                    AlertDialog(
                    title: Text('Are you sure?', style: TextStyle(color: Colors.blueGrey),),
                    content: Text('Do you want to Log Out?', style: TextStyle(color: Colors.blueGrey),),
                      actions: <Widget>[
                      Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                    backgroundColor: appcolor.redColor,
                                    shape: BeveledRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(2))
                                   )
                                 ),
                                     onPressed: () => Navigator.pop(context),
                                         child: Text('No', style: TextStyle(color: Colors.white),),
                               ),
                                ElevatedButton(
                                       style: ElevatedButton.styleFrom(
                                      backgroundColor: appcolor.redColor,
                                      shape: BeveledRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(2))
                                    )
                                ),
                                onPressed: ()async {
                                await preferences.remove('token');
                                Get.offAll(login_view());
                                },
                           child: Text('Yes', style: TextStyle(color: Colors.white),),
                        ),
                     ],
                    ),
                   ],
                 ),
                );
               },
            //  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),side:BorderSide(color: Colors.grey) ),
              leading: Icon(Icons.logout_outlined,color: Colors.red,),
              title: Text("Logout"),
            ),
          ),
        ],
      ),
    );
  }
}