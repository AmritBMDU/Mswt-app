import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:mswt/widgets/custom_appbar.dart';

class OrderHistory extends StatefulWidget {
  const OrderHistory({super.key});

  @override
  State<OrderHistory> createState() => _OrderHistoryState();
}

class _OrderHistoryState extends State<OrderHistory> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: customAppBar('Order History'),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            historyData(id: "sfadtdq12", status:"Delivered", date: "10-12-2023"),
            SizedBox(height: 10,),
            historyData(id: "fgsagd14", status: "Pending", date: "21-10-2023"),
            SizedBox(height: 10,),
            historyData(id: "tytcdc12", status: "Cancelled", date: "10-11-2023"),
            historyData(id: "sfadtdq12", status:"Delivered", date: "10-12-2023"),
            SizedBox(height: 10,),
            historyData(id: "fgsagd14", status: "Pending", date: "21-10-2023"),
            SizedBox(height: 10,),
            historyData(id: "tytcdc12", status: "Cancelled", date: "10-11-2023"),
            SizedBox(height: 10,),
             historyData(id: "sfadtdq12", status:"Delivered", date: "10-12-2023"),
            SizedBox(height: 10,),
           historyData(id: "fgsagd14", status: "Pending", date: "21-10-2023"),
             SizedBox(height: 10,),
           historyData(id: "tytcdc12", status: "Cancelled", date: "10-11-2023"),
          
          ],
        ),
      )
    );
  }
}

class historyData extends StatelessWidget {
   historyData({
    super.key,
    required this.id,
    required this.status,
     required this.date,

  });
  String id;
  String status;
  String date;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
       decoration: BoxDecoration(
        color: Colors.grey.shade200,
        border: Border.all(color: Colors.green),
        borderRadius: BorderRadius.circular(10)
       ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("${date}",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold),),
                 Row(
                    children: [
                      Text("ID: ",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,color: Colors.red),),
                        Text("${id}",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,color: Colors.red),),
                    ],
                  ),
                ],
              ),
              Column(
               crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              
                  Text("View Details"),
                    Row(
                    
                    children: [
                      Text("status: ",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,color: Colors.black),),
                        Text("${status}",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,color: status=="Delivered"||status=="delivered"? Colors.green:Colors.red),),
                    ],
                  )
                      
                ],
              )
                      
            ],
          ),
        ),
      ),
    );
  }
}